package tp01;

import java.util.ArrayList;
import java.util.List;


import generators.AlumnosGenerator;
import generators.ProfesoresGenerator;

public class Principal {

	public static void main(String[] args) {
		
		List<Alumno> la = new ArrayList<Alumno>();
		List<Profesor> lp = new ArrayList<Profesor>();
		AlumnosGenerator listaAlumnos = new AlumnosGenerator();
		ProfesoresGenerator listaProfesores = new ProfesoresGenerator();
		
		System.out.println("Lista de alumnos: ");
		la = listaAlumnos.generate();
		listaAlumnos.mostrarListaAlumnos(la);
		System.out.println("--------------------------------------------------------");
		System.out.println("Lista de profesores: ");
		lp = listaProfesores.generate();
		listaProfesores.MostrarProfesores(lp);
		

	}

}
